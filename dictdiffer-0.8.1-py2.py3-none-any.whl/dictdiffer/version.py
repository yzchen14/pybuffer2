# -*- coding: utf-8 -*-
# Do not change the format of this next line. Doing so risks breaking
# setup.py and docs/conf.py
"""Version information for dictdiffer package."""

__version__ = '0.8.1'
