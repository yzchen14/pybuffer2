# Copyright (c) 2010-2020 openpyxl

from .rule import Rule
