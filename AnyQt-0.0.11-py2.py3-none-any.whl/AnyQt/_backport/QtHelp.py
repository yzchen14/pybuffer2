from PyQt5.QtHelp import (
    QHelpContentItem,
    QHelpContentModel,
    QHelpContentWidget,
    QHelpEngine,
    QHelpEngineCore,
    QHelpIndexModel,
    QHelpIndexWidget,
    QHelpSearchEngine,
    QHelpSearchQuery,
    QHelpSearchQueryWidget,
    QHelpSearchResultWidget
)