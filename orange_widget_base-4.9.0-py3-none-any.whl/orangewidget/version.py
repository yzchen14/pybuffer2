# THIS FILE IS GENERATED FROM ORANGE-WIDGET-BASE SETUP.PY
short_version = '4.9.0'
version = '4.9.0'
full_version = '4.9.0'
git_revision = '34ee7eda0c0cccae6adcf2743e8f8ccfe593bc84'
release = True

if not release:
    version = full_version
    short_version += ".dev"
