
KWARGS = {
    "toolkit": "ipywidgets",
    "display": False,
}
