
from hyperspy_gui_ipywidgets.version import __version__
import hyperspy.api_nogui # necessary to register the toolkeys
# Importing as below registers the widgets when importing the module
import hyperspy_gui_ipywidgets.axes
import hyperspy_gui_ipywidgets.model
import hyperspy_gui_ipywidgets.tools
import hyperspy_gui_ipywidgets.preferences
import hyperspy_gui_ipywidgets.roi
import hyperspy_gui_ipywidgets.microscope_parameters
