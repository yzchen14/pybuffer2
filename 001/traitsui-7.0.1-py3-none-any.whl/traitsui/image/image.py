from pyface.image.image import *

from warnings import warn

warn(
    DeprecationWarning(
        "traitsui.image has been moved to pyface.image and will be removed in "
        "TraitsUI version 6.0"
    )
)
