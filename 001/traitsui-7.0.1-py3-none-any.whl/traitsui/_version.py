# THIS FILE IS GENERATED FROM TRAITS SETUP.PY
version = '7.0.1'
full_version = '7.0.1'
git_revision = 'Unknown'
is_released = True

if not is_released:
    version = full_version
