"""For of traitlet's link and dlink to enable linking traits.

"""

__version__ = "1.0.3"

from .link_traits import link, dlink, has_traits, has_traitlets
