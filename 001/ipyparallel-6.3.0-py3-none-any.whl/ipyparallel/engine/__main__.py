def main():
    from ipyparallel.apps import ipengineapp as app
    app.launch_new_instance()
    
if __name__ == '__main__':
    main()
