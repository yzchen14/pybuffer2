
# THIS FILE IS GENERATED FROM ORANGE SETUP.PY
short_version = '3.27.1'
version = '3.27.1'
full_version = '3.27.1'
git_revision = 'e4195b8d1954a7330c7417f6e74526d396017e01'
release = True

if not release:
    version = full_version
    short_version += ".dev"
