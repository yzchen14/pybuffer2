"""Learners"""

NAME = 'Model'

DESCRIPTION = 'Prediction.'

BACKGROUND = '#FAC1D9'

ICON = 'icons/Category-Model.svg'

PRIORITY = 4
