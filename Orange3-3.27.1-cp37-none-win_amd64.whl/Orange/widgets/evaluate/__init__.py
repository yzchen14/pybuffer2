"""
Widgets from Evaluate category

"""
NAME = "Evaluate"

DESCRIPTION = "Evaluate classification/regression performance."

BACKGROUND = "#C3F3F3"

ICON = "icons/Category-Evaluate.svg"

PRIORITY = 5
