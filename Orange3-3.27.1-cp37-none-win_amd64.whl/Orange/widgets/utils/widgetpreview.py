from orangewidget.utils.widgetpreview import WidgetPreview

__all__ = ["WidgetPreview"]
