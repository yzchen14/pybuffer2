"""
Canvas module
"""

# NotificationServer instance set in __main__.py
notification_server_instance = None
