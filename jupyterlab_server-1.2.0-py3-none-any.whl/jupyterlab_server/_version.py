version_info = (1, 2, 0)
__version__ = '.'.join(map(str, version_info[:3])) + ''.join(map(str, version_info[3:]))
