# -*- coding: utf-8 -*-

"""Provides all the generic data related to the payment."""

CREDIT_CARD_NETWORKS = [
    'Visa',
    'MasterCard',
    'Chase',
    'American Express',
    'Discover',
]
